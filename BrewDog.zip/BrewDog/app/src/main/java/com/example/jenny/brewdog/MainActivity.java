package com.example.jenny.brewdog;

import android.app.ActionBar;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;



public class MainActivity extends Activity {

    //Info om vem som ska filmas vilket används i filnamnet.
    //I den färdiga applikationen kommer denna info från de klick som görs i tidigare vyer.
    private String team = "F15";
    private String exercise = "Skott";
    private String player = "Sanna";

    //Variablar för kontakten med databasen
    private com.example.jenny.brewdog.DatabaseHandler dbHandler;

    private final static String LOG_TAG = MainActivity.class.getName();


    //String för att hantera uppdateringsinfo om kamerafunktion och lagring
    private String infoString = "";

    //För hantering av felmeddelanden
    private static String logtag = "BrewDog";

    //Talar om vilken kamera som ska användas
    private static int TAKE_PICTURE = 1;

    //Länk för att hålla reda på var fotot finns
    Uri imageUri;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Kopplar inspelningsknapp till händelse
        Button recordButton = (Button)findViewById(R.id.recordButton);
        recordButton.setOnClickListener(recordListener);

        //Kopplar bibliotekssknapp till händelse
        Button libraryButton = (Button)findViewById(R.id.libraryButton);
        libraryButton.setOnClickListener(libraryListener);

    }

    //Vad som händer vid knapptryck på biblioteksknapp
    private View.OnClickListener libraryListener = new View.OnClickListener(){
        public void onClick(View view){
            goToLibrary(view);
        }
    };

    //Metod för att gå till biblioteket
    private void goToLibrary(View view) {
        Intent libraryIntent = new Intent(this, LibraryActivity.class);
        startActivity(libraryIntent);
    }

    //Vad som händer vid knapptryck på "starta inspelning"-knapp
    private View.OnClickListener recordListener = new View.OnClickListener(){
        public void onClick(View view){
            takePhoto(view);
        }
    };

    //Metod för att ta foto
    private void takePhoto(View view) {
        Intent takePhotoIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePhotoIntent.resolveActivity(getPackageManager()) != null) {

            //skapar kalenderobjekt och formaterar hur tiden ska presenteras
            Calendar currentTime = new GregorianCalendar();
            SimpleDateFormat timeFormat = new SimpleDateFormat("yyyyMMdd-HHmmss");
            String timestamp = timeFormat.format(currentTime.getTime());

            //Skapar namn för fotofilen och skapar filen som sparas genom kamera-applikationen
            String imageName = timestamp + "_" + player + "_" + exercise + "_" + team;
            File currentImage = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), imageName);

            //Uri-objekt som länkar till foto
            imageUri = Uri.fromFile(currentImage);

            //skicka med uri-objektet till kameran
            takePhotoIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

            //starta kamera-applikation
            startActivityForResult(takePhotoIntent, TAKE_PICTURE);


        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent){
        super.onActivityResult(requestCode, resultCode, intent);

        //Om kamera-applikationen har fungerat korrekt och en bild har tagits
        if(resultCode == Activity.RESULT_OK) {
            //Länk för att hitta bild
            Uri selectedImage = imageUri;
            getContentResolver().notifyChange(selectedImage, null);

            try{
                //skapa databashanterare
                dbHandler = new com.example.jenny.brewdog.DatabaseHandler(getApplicationContext());
                //öppna databas
                dbHandler.open();

                //spara uri-länk i databas
                long id = dbHandler.insertPhoto(selectedImage.toString());

                //stäng databas
                dbHandler.close();

                if(id > 0){
                    //Meddelar användaren att bilden har sparats samt under vilket namn
                    infoString = "Filmen har sparats som : " + selectedImage.toString();
                    TextView tv = (TextView)findViewById(R.id.info);
                    tv.setText(infoString);


                    //Den imageView som bilden ska visas i
                    ImageView imageView = (ImageView)findViewById(R.id.picture);

                    ContentResolver cr = getContentResolver();
                    //Behövs för att kunna hämta in och visa bild
                    Bitmap bitmap;


                    //Testar att hämta in bilden som precis tagits och presenterar den i en imageView
                    try{
                        bitmap = MediaStore.Images.Media.getBitmap(cr, selectedImage);
                        imageView.setImageBitmap(bitmap);
                    }catch(Exception e){
                        Log.e(logtag, e.toString());
                    }


                }else{
                    //Meddelar användaren att bilden inte har sparats
                    infoString = "Filmen har inte sparats!!, Fel i kontakten med databasen.";
                    TextView tv = (TextView)findViewById(R.id.info);
                    tv.setText(infoString);
                }

            }catch (Exception e){
                infoString = e.toString();
                TextView tv = (TextView)findViewById(R.id.info);
                tv.setText(infoString);
            }



        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        return super.onOptionsItemSelected(item);
    }


}
