package com.example.jenny.brewdog;


import android.app.Activity;
import android.content.ContentResolver;

import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class LibraryActivity extends Activity {

    //Lista för att hålla reda på alla foton
    private ArrayList<Uri> libraryList;

    //Variablar för kontakten med databasen
    private com.example.jenny.brewdog.DatabaseHandler dbHandler;

    private final static String LOG_TAG = LibraryActivity.class.getName();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_library);

        setUpLibrary();

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_library, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //Vad som händer vid knapptryck på raderingsknapp
        if (id == R.id.deletePictures) {
            Boolean result = deleteAllPictures();
            setContentView(R.layout.activity_library);
            setUpLibrary();
            return result;
        }

        return super.onOptionsItemSelected(item);
    }


    //Metod för att gå till biblioteket
    private boolean deleteAllPictures() {
        try{
            //skapar databashanterare
            dbHandler = new DatabaseHandler(this.getApplicationContext());
            Log.d(LOG_TAG, " dbh: " + dbHandler);
            dbHandler.open();
            Log.d(LOG_TAG, " db has been opened");
            dbHandler.deleteAllPhotos();
            Log.d(LOG_TAG, " db All photos has been deleted");
            dbHandler.close();
            return true;
        }catch (Exception e){
            Log.d(LOG_TAG, "Exception...." + e);
            Log.d(LOG_TAG, "Exception...." + e.getStackTrace());
        }

        return false;
    }



    //metod för att hämta fotolänkar från databasen och returnera som en lista med Uri-objekt
    public void setLibraryList(){


        try{
            //skapar databashanterare
            dbHandler = new DatabaseHandler(this.getApplicationContext());
            Log.d(LOG_TAG, " dbh: " + dbHandler);
            dbHandler.open();
            Log.d(LOG_TAG, " db has been opened");
            Log.d("IDIOTHENRIK", " tstetet");

            ArrayList<String> databaseList = dbHandler.getAllPhotos();
            Log.d(LOG_TAG, " list: " + databaseList.size());
            Log.d("IDIOTHENRIK", " list: " + databaseList.size());
            libraryList = new ArrayList<Uri>();
            for(int i = 0; i<databaseList.size(); i++){
                String photo = databaseList.get(i);
                libraryList.add(Uri.parse(photo));
            }
            dbHandler.close();
        }catch (Exception e){
            Log.d(LOG_TAG, "Exception...." + e);
            Log.d(LOG_TAG, "Exception...." + e.getStackTrace());

            libraryList = new ArrayList<Uri>();
            libraryList.add(Uri.parse(e.toString()));
        }
    }


    //metod för att hämta in länkar till alla bilder och visa dem i biblioteket
    private void setUpLibrary() {
        setLibraryList();
        if (libraryList.isEmpty()) {
            return;
        } else {

            //Skapa länk till scrollview
            LinearLayout layout = (LinearLayout) findViewById(R.id.photoGallery);

            //Varje Uri(bild) i bibliotekslistan hämtas och läggs till i scrollvyn för visning i applikationen
            for (int i = 0; i < libraryList.size(); i++) {
                //Länk för att hitta bild
                Uri selectedImage = libraryList.get(i);
                getContentResolver().notifyChange(selectedImage, null);

                //Den imageView som bilden ska visas i
                ImageView imageView = new ImageView(this);
                imageView.setMaxHeight(80);
                imageView.setMaxWidth(80);
                imageView.setId(i);

                //text till bild
                TextView textView = new TextView(this);
                textView.setMaxHeight(50);
                textView.setTextSize(12);
                textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                textView.setText(selectedImage.getPath() + "\n");

                ContentResolver cr = getContentResolver();
                //Behövs för att kunna hämta in och visa bild
                Bitmap bitmap;

                //Testar att hämta in bilden som precis tagits och presenterar den i en imageView
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(cr, selectedImage);
                    imageView.setImageBitmap(bitmap);
                    layout.addView(imageView);
                    layout.addView(textView);
                } catch (Exception e) {
                    Toast.makeText(this, e.toString(), Toast.LENGTH_LONG);
                }
            }
        }
    }


}
