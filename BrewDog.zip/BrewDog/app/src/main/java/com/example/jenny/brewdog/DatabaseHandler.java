package com.example.jenny.brewdog;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;


/**
 * Simple notes database access helper class. Defines the basic CRUD operations
 * for the notepad example, and gives the ability to list all notes as well as
 * retrieve or modify a specific note.
 *
 * This has been improved from the first version of this tutorial through the
 * addition of better error handling and also using returning a Cursor instead
 * of using a collection of inner classes (which is less scalable and not
 * recommended).
 */
public class DatabaseHandler {

    public static final String URI = "uri";

    private static final String TABLE_NAME = "phototable";
    private static final String DATABASE_NAME = "brewdog.db";
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_CREATE = "create table phototable (uri text not null primary key)";

    private final static String LOG_TAG = DatabaseHandler.class.getName();

    DatabaseHelper dbHelper;
    Context ctx;
    SQLiteDatabase db;

    public DatabaseHandler(Context ctx){
        this.ctx = ctx;
        dbHelper = new DatabaseHelper(ctx);
    }

    public DatabaseHandler open(){
        Log.d(LOG_TAG, "   open()");
        db = dbHelper.getWritableDatabase();
        Log.d(LOG_TAG, "   open() => db: " + db);
        return this;
    }

    public void close(){
        dbHelper.close();
    }

    public long insertPhoto(String uri){
        ContentValues content = new ContentValues();
        content.put(URI, uri);
        return db.insertOrThrow(TABLE_NAME, null, content);

    }

    public ArrayList<String> getAllPhotos(){
        ArrayList<String> photoList = new ArrayList<String>();
        String selectQuery = "SELECT DISTINCT * FROM phototable";
        Cursor cursor = db.rawQuery(selectQuery, null);

        Log.d(LOG_TAG, " list size: " + photoList.size());
        Log.d(LOG_TAG, " cursor: " + cursor);

        if (cursor.moveToFirst()) {
            Log.d(LOG_TAG, " entering loop");
            do{
                Log.d(LOG_TAG, "   in loop, name: " + cursor.getString(0));
                String photo = cursor.getString(0);
                photoList.add(photo);
                Log.d(LOG_TAG, "   in loop size : " + photoList.size());
            }while(cursor.moveToNext());

        }
        Log.d(LOG_TAG, " list size: " + photoList.size());
        Log.d(LOG_TAG, " .... arggggg....... end of it all ");

        return photoList;
    }

    public void deleteAllPhotos(){
        Log.d(LOG_TAG, " beginning of delete all photos");
        db = dbHelper.getWritableDatabase();
        db.execSQL("DELETE FROM phototable;");
        Log.d(LOG_TAG, "end of delete all photos ");
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {

        public DatabaseHelper(Context ctx){
            super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
            Log.d(LOG_TAG, "private:   ():  ctx: " + ctx);

        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            Log.d(LOG_TAG, "private:   ---> onCreate()");
            try{
                db.execSQL(DATABASE_CREATE);
            }catch(SQLException e){
                e.printStackTrace();
            }
            Log.d(LOG_TAG, "private:   <-- onCreate()");


        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.d(LOG_TAG, "private:   ---> onUpgrade()");

            db.execSQL("DROP TABLE IF EXISTS phototable ");
            Log.d(LOG_TAG, "private:   ---- onUpgrade()");
            onCreate(db);
            Log.d(LOG_TAG, "private:   <--- onUpgrade()");
        }
    }
}

